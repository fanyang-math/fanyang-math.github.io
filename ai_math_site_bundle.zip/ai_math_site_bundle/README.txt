Suggested placement in the root of the Quarto website repository:

  teaching.qmd               (replace the existing source)
  ai-for-mathematics.qmd     (new landing page)
  ai-for-mathematics.pdf     (the current PDF)

Then render the site normally, e.g.:

  quarto render

No navbar change is needed: the new page is linked from Teaching.

If _quarto.yml contains an explicit project.render list, add ai-for-mathematics.qmd to that list. If the project renders all root-level .qmd files, no configuration change is needed.

The landing page deliberately uses the site's existing page-intro and page-feature/compact-feature classes, so no CSS change is required.

Note: only the PDF was copied. The final user-edited LaTeX source was not supplied with the website files, so this bundle does not publish a .tex source link.
